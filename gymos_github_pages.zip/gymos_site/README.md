# GymOS

Mobile-first gym tracker. Static website with browser-local data storage.

## Publish on GitHub Pages
1. Create a public repository called `gymos`.
2. Upload `index.html` to the root of the repository and commit.
3. Go to Settings > Pages > Build and deployment.
4. Select Deploy from a branch, `main`, `/ (root)`, and Save.
5. Open `https://YOUR_USERNAME.github.io/gymos/` in Safari.
6. Safari Share > Add to Home Screen.

Workout, protein and body-weight data are stored in the browser on this device, not in GitHub. Do not rely on local storage alone: export backups regularly. Clearing website data or changing browser/origin may erase or isolate saved data. An installed Home Screen web app may use a separate storage context from Safari; start logging in the Home Screen app after installation and use backups for migration.
